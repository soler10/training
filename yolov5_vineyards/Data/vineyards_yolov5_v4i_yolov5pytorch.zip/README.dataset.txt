# vineyards_yolov5 > 2023-03-13 8:45am
https://universe.roboflow.com/objectdetection-1qr9x/vineyards_yolov5

Provided by a Roboflow user
License: CC BY 4.0

